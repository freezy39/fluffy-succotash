import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import datasets, layers, models

# Reproducibility
np.random.seed(456)
tf.random.set_seed(456)

# Create output folder
output_dir = "cifar10_outputs"
os.makedirs(output_dir, exist_ok=True)

# Load CIFAR-10 data
(x_train, y_train), (x_test, y_test) = datasets.cifar10.load_data()

# Normalize pixel values to 0-1
x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0

class_names = [
    "airplane", "automobile", "bird", "cat", "deer",
    "dog", "frog", "horse", "ship", "truck"
]

# Save a sample image grid
plt.figure(figsize=(10, 6))
for i in range(12):
    plt.subplot(3, 4, i + 1)
    plt.imshow(x_train[i])
    plt.title(class_names[int(y_train[i])])
    plt.axis("off")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "cifar10_sample_images.png"), dpi=200)
plt.close()

# Build CNN model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation="relu", input_shape=(32, 32, 3)),
    layers.MaxPooling2D((2, 2)),

    layers.Conv2D(64, (3, 3), activation="relu"),
    layers.MaxPooling2D((2, 2)),

    layers.Conv2D(64, (3, 3), activation="relu"),

    layers.Flatten(),
    layers.Dense(64, activation="relu"),
    layers.Dense(10, activation="softmax")
])

model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)

print("Model summary:")
model.summary()

# Train model
history = model.fit(
    x_train,
    y_train,
    epochs=10,
    validation_split=0.2,
    batch_size=64,
    verbose=1
)

# Evaluate on test set
test_loss, test_accuracy = model.evaluate(x_test, y_test, verbose=2)

print(f"\nTest Loss: {test_loss:.4f}")
print(f"Test Accuracy: {test_accuracy:.4f}")

# Save model
model.save(os.path.join(output_dir, "cifar10_cnn_model.keras"))

# Plot training and validation accuracy
plt.figure(figsize=(8, 5))
plt.plot(history.history["accuracy"], label="Training Accuracy")
plt.plot(history.history["val_accuracy"], label="Validation Accuracy")
plt.title("Training and Validation Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "accuracy_curve.png"), dpi=200)
plt.close()

# Plot training and validation loss
plt.figure(figsize=(8, 5))
plt.plot(history.history["loss"], label="Training Loss")
plt.plot(history.history["val_loss"], label="Validation Loss")
plt.title("Training and Validation Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "loss_curve.png"), dpi=200)
plt.close()

# Generate predictions on test set
predictions = model.predict(x_test[:12])
predicted_labels = np.argmax(predictions, axis=1)

# Save prediction examples
plt.figure(figsize=(10, 6))
for i in range(12):
    plt.subplot(3, 4, i + 1)
    plt.imshow(x_test[i])
    true_label = class_names[int(y_test[i])]
    pred_label = class_names[int(predicted_labels[i])]
    plt.title(f"T: {true_label}\nP: {pred_label}", fontsize=8)
    plt.axis("off")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "prediction_examples.png"), dpi=200)
plt.close()

print("\nSaved files:")
print(os.path.join(output_dir, "cifar10_sample_images.png"))
print(os.path.join(output_dir, "accuracy_curve.png"))
print(os.path.join(output_dir, "loss_curve.png"))
print(os.path.join(output_dir, "prediction_examples.png"))
print(os.path.join(output_dir, "cifar10_cnn_model.keras"))